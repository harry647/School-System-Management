# School System Management v1.0.0

This archive contains the complete School System Management application.

## Contents
- SchoolSystemManagement.exe - Main application executable
- _internal/ - Application dependencies (required)
- book_import_template.xlsx - Book import template
- student_import_template.xlsx - Student import template
- README.md - Application documentation
- LICENSE.txt - License information

## Installation
1. Extract all files to a folder on your computer
2. Run SchoolSystemManagement.exe
3. The application will create its database automatically on first run

## System Requirements
- Windows 7 SP1 or later (64-bit recommended)
- 2GB RAM minimum, 4GB recommended
- 500MB free disk space

## Default Login Credentials
- Username: admin
- Password: harry123

## Support
For issues or questions, refer to the README.md file.

Built on: 2026-01-22 20:23:53
Version: 1.0.0
